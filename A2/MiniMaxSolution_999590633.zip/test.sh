./MiniMax_search 2323 1 6 1 10 0.9
