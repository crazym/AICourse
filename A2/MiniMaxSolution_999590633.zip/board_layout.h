// Definitions affecting the layout of the game board
// Please do not change these.

#ifndef __board_layout_header

#define __board_layout_header
#define size_X 32
#define size_Y 32
#define graph_size size_X*size_Y

#endif
